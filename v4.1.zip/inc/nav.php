<section class="related fix">
<div class="l">
	<?php previous_post_link('%link'); ?> 
</div>
<div class="r">
	<?php next_post_link('%link'); ?> 
</div>
</section>
