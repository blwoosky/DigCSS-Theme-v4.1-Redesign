<?php get_header(); ?>
		
		<div class="BoxInner errorPage">
			<i>Error</i><i>404</i>
			<p>对不起，页面没找到~~</p>
		</div>
	</div>
<?php get_footer(); ?>