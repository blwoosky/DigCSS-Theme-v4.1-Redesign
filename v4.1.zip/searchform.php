<div class="r searchForm rel">
    <form action="<?php bloginfo('url');?>" method="get">
        <button class="searchBtn">
            <svg viewBox="0 0 100 100">
                <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-search"></use>
            </svg>
        </button>
        <input type="text" class="abs" required name="s" id="s" placeholder="在此输入搜索关键字">
    </form>
</div>